# HarborGrill – Vercel Deployable Example (Next.js 14 + Tailwind)

This repo contains the Harbor Grill example page and minimal UI components.  
Push to GitHub and import into Vercel for instant deploy.

## Dev
```bash
npm install
npm run dev
```
## Build
```bash
npm run build
npm start
```
